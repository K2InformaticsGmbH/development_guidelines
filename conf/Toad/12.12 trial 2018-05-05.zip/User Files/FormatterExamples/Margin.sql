/*  The examples below are editable and saved on a per-tab basis */



INSERT INTO my_table1 (my_num1, my_num2)
     VALUES (12, 100);


-- assuming parameters are wrapped

BEGIN
    a_proc_call (aaaaaaaaaa,
                 bbbbbbbbbbbbbbbbb,
                 ccccccccccccccccccccccccccc,
                 dddddddddddddddddd,
                 eeeeeeeeeeeeeeeeee,
                 ffffffffffffffffffffff);
END; 