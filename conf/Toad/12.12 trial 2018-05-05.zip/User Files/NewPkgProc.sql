  /************************************************************************
   %BodyProcName%
   Created: %DateTime% by %UserName%
   Purpose:
  ************************************************************************/
  PROCEDURE %BodyProcName%%BodyProcParams% IS
    tmpVar NUMBER;
  BEGIN
    tmpVar := 0;
  END %BodyProcName%;

