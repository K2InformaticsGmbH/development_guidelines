/*  The examples below are editable and saved on a per-tab basis */


SELECT   1 + 2 + 1 + 2 + 1 + 2 + 1 + 2,
         1 + 2 + 1 + 2 + 1 + 2 + 1 + 2,
         1 + 2 + 1 + 2 + 1 + 2 + 1 + 2,
         1 + 2 + 1 + 2 + 1
  FROM   tab;

BEGIN
     my_result :=       variable_one
                      + variable_two
                      + variable_three
                      + variable_four
                      - variable_five
                      + variable_six;

     your_result :=     variable_one
                      * variable_two
                      / variable_three
                      * variable_four
                      * variable_five;
END;

SELECT   *
  FROM   tab
 WHERE     variable_one
         + variable_two
         - variable_
         + variable_three
         + function_one (variable_four + variable_five - variable_six)
         - function_two (variable_seven + variable_eight + variable_nine)
         + variable_ten
         - variable_eleven;

BEGIN
     aaaaaaaaaaaaaaa :=   bbbbbbbb + ccccccccc + ddddddddd + eeeeeeeee;

     aaaaaaaaaaaaaaa :=   bbbbbbbb + ccccccccc + ddddddddd;

     aaaaaaaaaaaaaaa :=   bbbbbbbb + ccccccccc;

     aaaaaaaaaaaaaaa :=   bbbbbbbb;
END;

BEGIN
     x :=      TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size))
            || TRIM (TO_CHAR (cn_font_size));
END;