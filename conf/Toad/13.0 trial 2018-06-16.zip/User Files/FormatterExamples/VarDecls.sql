/*  The examples below are editable and saved on a per-tab basis */

DECLARE
    a                              NUMBER;
    b                              NUMBER := 1;
BEGIN
    NULL;
END;

CREATE TABLE tab
(
    a NUMBER,
    b NUMBER
);

CREATE VIEW vw
(
    a,
    b,
    c,
    d
)
AS
    SELECT a, b, c, d FROM tab;

CREATE PACKAGE BODY pkg
AS
    PROCEDURE p1
    IS
        h_koers_vrmnt                  NUMBER (12, 6);
        h_koers_boekheeeeeeee          NUMBER (12, 6);
        h_koers_vm                     NUMBER (9, 6);
        h_systeem                      NUMBER (1);
        h_munt_bkh                     VARCHAR2 (3) := 'USD';
        h_euromunt_vm                  NUMBER (1);
        h_dummy                        VARCHAR2 (1000)
            := 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
        h_foutnr                       NUMBER (3) := 100;
        h_aankoop                      NUMBER (1);
        h_verkoop                      NUMBER (1) := 1;
    BEGIN
        NULL;
    END;

    PROCEDURE p2
    IS
        h_koers_vrmnt                  NUMBER (12, 6);
        h_koers_boekh                  NUMBER (12, 6);
        h_koers_vm                     NUMBER (9, 6);
        h_systeem                      NUMBER (1);
        h_munt_bkh                     VARCHAR2 (3);
        h_euromunt_vm                  NUMBER (1);
        h_dummy                        VARCHAR2 (1);
        h_foutnr                       NUMBER (3);
        h_aankoop                      NUMBER (1);
        h_verkoop                      NUMBER (1);
    BEGIN
        NULL;
    END;
END; 