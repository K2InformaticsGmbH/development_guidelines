<RULESET title="Informational" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38447.6751145139</CREATED>
<MODIFIED>38447.6753553935</MODIFIED>
<COMMENTS>Rules in this set identify areas of code that should be reviewed to possibly improve the application, but do not indicate a current or imminent problem.</COMMENTS>
<RULESET_TOTAL>121</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <SEVERITY sev="0" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>